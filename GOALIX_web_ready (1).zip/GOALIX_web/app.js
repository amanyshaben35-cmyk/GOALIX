const matches=[['الدوري الإنجليزي','ليفربول','أرسنال','20:30'],['الدوري الإسباني','برشلونة','فالنسيا','22:00'],['الدوري الإيطالي','ميلان','روما','21:45']];
document.querySelector('#matches').innerHTML=matches.map(m=>`<article class="match"><div class="league">${m[0]}</div><div class="teams"><b>${m[1]}</b><span>×</span><b>${m[2]}</b></div><small>${m[3]}</small></article>`).join('');
const preds=[['ليفربول × أرسنال','فوز/تعادل ليفربول','82%'],['برشلونة × فالنسيا','أكثر من 1.5 هدف','78%'],['ميلان × روما','أقل من 4.5 أهداف','86%']];
document.querySelector('#preds').innerHTML=preds.map(p=>`<article class="prediction"><small>${p[0]}</small><h3>${p[1]}</h3><div class="confidence">${p[2]}</div><small>مؤشر ثقة تحليلي</small></article>`).join('');
function subscribe(){alert('النسخة الحالية تجريبية. المرحلة التالية: حسابات المستخدمين وربط GOALIX Premium والدفع.');}
